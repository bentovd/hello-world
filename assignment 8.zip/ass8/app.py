from flask import Flask, redirect, url_for, render_template, request, flash
from flask import request

app = Flask(__name__)


@app.route('/')
def foo():
    return render_template('ass6.html')


@app.route('/userList')
def userList():
    return render_template('userList.html')


@app.route('/assignment8')
def assignment8():
    my_hobbies = ['singing', 'cooking', 'playing']
    name = "danielle"
    return render_template('assignment8.html', my_hobbies=my_hobbies, name=name)


@app.route('/blockExample')
def extend_of_assignment8():
    my_hobbies = ['singing', 'cooking', 'playing']
    name = "danielle"
    return render_template('blockExample.html', my_hobbies=my_hobbies, name=name)

if __name__ == '__main__':
    app.run(debug=True)