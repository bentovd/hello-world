 function big(){document.getElementById("danielle").style.width="30vw" }
 function regular(){document.getElementById("danielle").style.width="26vw" }